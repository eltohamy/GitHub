package io.mbition.github.ui.users

import io.mbition.github.models.User

/**
 * Created by Tohamy on 3/15/2018.
 */
data class UsersData(val users: List<User>)